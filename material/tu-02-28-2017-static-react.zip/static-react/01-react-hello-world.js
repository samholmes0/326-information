class HelloMessage extends React.Component {
  render() {
    return <div>Hello {this.props.name}</div>;
  }
}

let mountNode = document.getElementById('app');

ReactDOM.render(<HelloMessage name="John" />, mountNode);
