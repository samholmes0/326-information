class TodoApp extends React.Component {

  render() {
    return (
      <div>
        <h3>{this.props.owner}'s TODO List</h3>
        <TodoList items={this.props.items} />
        <TodoForm items={this.props.items} />
      </div>
    );
  }

}

class TodoForm extends React.Component {
  render() {
    return (
      <form>
        <input value="" />
        <button>{'Add #' + (this.props.items.length + 1)}</button>
      </form>
    );
  }
}

class TodoList extends React.Component {
  render() {
    return (
      <ul>
        {this.props.items.map(item => (
           <li key={item.key}>{item.text}</li>
         ))}
      </ul>
    );
  }
}

// Our very, very simple model of a TODO application:
let model = {
  owner: 'Matilda',
  items: [
    // What is the key for?
    { key: 1, text: 'Feed the dog' },
    { key: 2, text: 'Go grocery shopping' },
    { key: 3, text: 'Wash the clothes' },
    { key: 4, text: 'Read Alexander Hamilton historical fiction' },
  ]
};

let mountNode = document.getElementById('app');

ReactDOM.render(<TodoApp owner={model.owner} items={model.items}/>, mountNode);
